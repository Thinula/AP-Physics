#include "Matrix.h"
#include <iostream>

using namespace std;

//Matrix::Matrix()
//{
//    //ctor
//}
//
//Matrix::~Matrix()
//{
//    //dtor
//}

int main()
{
    int r,c;
    cout << "Enter the number of rows in your data set: ";
    cin >> r;
    cout << "Enter the number of columns in your data set: ";
    cin >> c;
}
